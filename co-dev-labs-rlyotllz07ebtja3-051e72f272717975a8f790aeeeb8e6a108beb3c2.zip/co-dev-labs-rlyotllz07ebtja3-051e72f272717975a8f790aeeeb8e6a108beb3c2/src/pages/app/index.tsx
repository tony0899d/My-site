import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import { motion } from 'framer-motion';
import { useAuth } from '@/contexts/AuthContext';
import { useExpense } from '@/contexts/ExpenseContext';
import Header from '@/components/Header';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { 
  TrendingUp, 
  TrendingDown,
  DollarSign, 
  Calendar,
  PieChart,
  BarChart3,
  Plus,
  Zap,
  Target,
  AlertTriangle
} from 'lucide-react';
import { PieChart as RechartsPieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, LineChart, Line } from 'recharts';
import { format, startOfMonth, endOfMonth, subMonths, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { toast } from 'sonner';

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.5 }
};

const staggerContainer = {
  animate: {
    transition: {
      staggerChildren: 0.1
    }
  }
};

export default function Dashboard() {
  const router = useRouter();
  const { user, isGuest } = useAuth();
  const { transactions, categories, budgets, addTransaction } = useExpense();
  
  const [isQuickAddOpen, setIsQuickAddOpen] = useState(false);
  const [quickAmount, setQuickAmount] = useState('');
  const [quickCategory, setQuickCategory] = useState('');
  const [quickDescription, setQuickDescription] = useState('');

  // Redirect if not authenticated
  useEffect(() => {
    if (!user && !isGuest) {
      router.push('/');
    }
  }, [user, isGuest, router]);

  if (!user && !isGuest) {
    return null;
  }

  // Calculate current month data
  const currentDate = new Date();
  const currentMonthStart = startOfMonth(currentDate);
  const currentMonthEnd = endOfMonth(currentDate);
  const previousMonthStart = startOfMonth(subMonths(currentDate, 1));
  const previousMonthEnd = endOfMonth(subMonths(currentDate, 1));

  const currentMonthTransactions = transactions.filter(t => {
    const transactionDate = parseISO(t.date);
    return transactionDate >= currentMonthStart && transactionDate <= currentMonthEnd;
  });

  const previousMonthTransactions = transactions.filter(t => {
    const transactionDate = parseISO(t.date);
    return transactionDate >= previousMonthStart && transactionDate <= previousMonthEnd;
  });

  const currentMonthTotal = currentMonthTransactions.reduce((sum, t) => sum + t.amount, 0);
  const previousMonthTotal = previousMonthTransactions.reduce((sum, t) => sum + t.amount, 0);
  const monthlyChange = previousMonthTotal > 0 ? ((currentMonthTotal - previousMonthTotal) / previousMonthTotal) * 100 : 0;

  // Calculate daily average
  const daysInMonth = currentDate.getDate();
  const dailyAverage = currentMonthTotal / daysInMonth;

  // Find biggest expense
  const biggestExpense = currentMonthTransactions.reduce((max, t) => t.amount > max.amount ? t : max, { amount: 0, description: 'Nenhum' });

  // Days without spending
  const spendingDays = new Set(currentMonthTransactions.map(t => format(parseISO(t.date), 'yyyy-MM-dd')));
  const daysWithoutSpending = daysInMonth - spendingDays.size;

  // Category data for pie chart
  const categoryTotals = currentMonthTransactions.reduce((acc, t) => {
    acc[t.category] = (acc[t.category] || 0) + t.amount;
    return acc;
  }, {} as Record<string, number>);

  const pieData = Object.entries(categoryTotals).map(([name, value]) => {
    const category = categories.find(c => c.name === name);
    return {
      name,
      value,
      color: category?.color || '#8884d8'
    };
  });

  // Monthly comparison data
  const last6Months = Array.from({ length: 6 }, (_, i) => {
    const date = subMonths(currentDate, 5 - i);
    const monthStart = startOfMonth(date);
    const monthEnd = endOfMonth(date);
    const monthTransactions = transactions.filter(t => {
      const transactionDate = parseISO(t.date);
      return transactionDate >= monthStart && transactionDate <= monthEnd;
    });
    const total = monthTransactions.reduce((sum, t) => sum + t.amount, 0);
    
    return {
      month: format(date, 'MMM', { locale: ptBR }),
      total
    };
  });

  // Daily spending for current month
  const dailyData = Array.from({ length: daysInMonth }, (_, i) => {
    const day = i + 1;
    const dayStr = format(new Date(currentDate.getFullYear(), currentDate.getMonth(), day), 'yyyy-MM-dd');
    const dayTransactions = currentMonthTransactions.filter(t => t.date.startsWith(dayStr));
    const total = dayTransactions.reduce((sum, t) => sum + t.amount, 0);
    
    return {
      day,
      total
    };
  });

  // Budget alerts
  const budgetAlerts = budgets.filter(budget => {
    const category = categories.find(c => c.id === budget.categoryId);
    if (!category) return false;
    
    const categorySpent = categoryTotals[category.name] || 0;
    const percentage = (categorySpent / budget.monthlyLimit) * 100;
    return percentage > 80; // Alert when over 80%
  });

  const handleQuickAdd = () => {
    if (!quickAmount || !quickCategory) {
      toast.error('Preencha valor e categoria');
      return;
    }

    const amount = parseFloat(quickAmount.replace(',', '.'));
    if (isNaN(amount) || amount <= 0) {
      toast.error('Valor inválido');
      return;
    }

    addTransaction({
      date: format(new Date(), 'yyyy-MM-dd'),
      category: quickCategory,
      description: quickDescription || 'Gasto rápido',
      paymentMethod: 'Dinheiro',
      amount,
      tags: []
    });

    toast.success(`R$ ${amount.toFixed(2)} adicionado com sucesso!`);
    setIsQuickAddOpen(false);
    setQuickAmount('');
    setQuickCategory('');
    setQuickDescription('');
  };

  return (
    <>
      <Head>
        <title>Dashboard - Controle de Gastos</title>
        <meta name="description" content="Seu dashboard de controle de gastos pessoais" />
      </Head>

      <div className="bg-background min-h-screen">
        <Header />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <motion.div
            initial="initial"
            animate="animate"
            variants={staggerContainer}
          >
            {/* Welcome Section */}
            <motion.div variants={fadeInUp} className="mb-8">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                  <h1 className="text-3xl font-bold text-primary">
                    Olá, {user?.name || 'Visitante'}! 👋
                  </h1>
                  <p className="text-muted-foreground">
                    Aqui está o resumo dos seus gastos de {format(currentDate, 'MMMM yyyy', { locale: ptBR })}
                  </p>
                </div>
                
                {/* Quick Add Button */}
                <Dialog open={isQuickAddOpen} onOpenChange={setIsQuickAddOpen}>
                  <DialogTrigger asChild>
                    <Button size="lg" className="flex items-center gap-2">
                      <Zap className="w-5 h-5" />
                      Gastei hoje
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Adicionar gasto de hoje</DialogTitle>
                      <DialogDescription>
                        Registre rapidamente um gasto de hoje
                      </DialogDescription>
                    </DialogHeader>
                    
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="amount">Valor (R$)</Label>
                        <Input
                          id="amount"
                          type="text"
                          placeholder="0,00"
                          value={quickAmount}
                          onChange={(e) => setQuickAmount(e.target.value)}
                        />
                      </div>
                      
                      <div>
                        <Label htmlFor="category">Categoria</Label>
                        <Select value={quickCategory} onValueChange={setQuickCategory}>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione uma categoria" />
                          </SelectTrigger>
                          <SelectContent>
                            {categories.map(category => (
                              <SelectItem key={category.id} value={category.name}>
                                {category.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div>
                        <Label htmlFor="description">Descrição (opcional)</Label>
                        <Input
                          id="description"
                          type="text"
                          placeholder="Ex: Almoço no restaurante"
                          value={quickDescription}
                          onChange={(e) => setQuickDescription(e.target.value)}
                        />
                      </div>
                    </div>
                    
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setIsQuickAddOpen(false)}>
                        Cancelar
                      </Button>
                      <Button onClick={handleQuickAdd}>
                        Adicionar
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
            </motion.div>

            {/* Budget Alerts */}
            {budgetAlerts.length > 0 && (
              <motion.div variants={fadeInUp} className="mb-8">
                <Card className="border-orange-200 bg-orange-50 dark:border-orange-800 dark:bg-orange-950">
                  <CardHeader>
                    <CardTitle className="flex items-center text-orange-800 dark:text-orange-200">
                      <AlertTriangle className="w-5 h-5 mr-2" />
                      Alertas de Orçamento
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {budgetAlerts.map(budget => {
                        const category = categories.find(c => c.id === budget.categoryId);
                        const spent = categoryTotals[category?.name || ''] || 0;
                        const percentage = (spent / budget.monthlyLimit) * 100;
                        
                        return (
                          <div key={budget.id} className="flex items-center justify-between">
                            <span className="text-sm font-medium">
                              {category?.name}: R$ {spent.toFixed(2)} de R$ {budget.monthlyLimit.toFixed(2)}
                            </span>
                            <Badge variant={percentage > 100 ? "destructive" : "secondary"}>
                              {percentage.toFixed(0)}%
                            </Badge>
                          </div>
                        );
                      })}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}

            {/* KPI Cards */}
            <motion.div variants={fadeInUp} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total do Mês</CardTitle>
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">R$ {currentMonthTotal.toFixed(2)}</div>
                  <p className="text-xs text-muted-foreground flex items-center">
                    {monthlyChange > 0 ? (
                      <>
                        <TrendingUp className="w-3 h-3 mr-1 text-red-500" />
                        +{monthlyChange.toFixed(1)}% vs mês anterior
                      </>
                    ) : monthlyChange < 0 ? (
                      <>
                        <TrendingDown className="w-3 h-3 mr-1 text-green-500" />
                        {monthlyChange.toFixed(1)}% vs mês anterior
                      </>
                    ) : (
                      'Mesmo valor do mês anterior'
                    )}
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Média Diária</CardTitle>
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">R$ {dailyAverage.toFixed(2)}</div>
                  <p className="text-xs text-muted-foreground">
                    Baseado em {daysInMonth} dias
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Maior Compra</CardTitle>
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">R$ {biggestExpense.amount.toFixed(2)}</div>
                  <p className="text-xs text-muted-foreground truncate">
                    {biggestExpense.description}
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Dias sem Gastar</CardTitle>
                  <Target className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{daysWithoutSpending}</div>
                  <p className="text-xs text-muted-foreground">
                    de {daysInMonth} dias no mês
                  </p>
                </CardContent>
              </Card>
            </motion.div>

            {/* Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
              {/* Pie Chart */}
              <motion.div variants={fadeInUp}>
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <PieChart className="w-5 h-5 mr-2" />
                      Gastos por Categoria
                    </CardTitle>
                    <CardDescription>
                      Distribuição dos gastos de {format(currentDate, 'MMMM', { locale: ptBR })}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {pieData.length > 0 ? (
                      <ResponsiveContainer width="100%" height={300}>
                        <RechartsPieChart>
                          <Pie
                            data={pieData}
                            cx="50%"
                            cy="50%"
                            outerRadius={80}
                            dataKey="value"
                            label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                          >
                            {pieData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                          </Pie>
                          <Tooltip formatter={(value: number) => [`R$ ${value.toFixed(2)}`, 'Valor']} />
                        </RechartsPieChart>
                      </ResponsiveContainer>
                    ) : (
                      <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                        Nenhum gasto registrado este mês
                      </div>
                    )}
                  </CardContent>
                </Card>
              </motion.div>

              {/* Monthly Comparison */}
              <motion.div variants={fadeInUp}>
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <BarChart3 className="w-5 h-5 mr-2" />
                      Comparação Mensal
                    </CardTitle>
                    <CardDescription>
                      Últimos 6 meses
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={last6Months}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip formatter={(value: number) => [`R$ ${value.toFixed(2)}`, 'Total']} />
                        <Bar dataKey="total" fill="hsl(var(--primary))" />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </motion.div>
            </div>

            {/* Daily Spending Chart */}
            <motion.div variants={fadeInUp}>
              <Card>
                <CardHeader>
                  <CardTitle>Gastos Diários - {format(currentDate, 'MMMM yyyy', { locale: ptBR })}</CardTitle>
                  <CardDescription>
                    Evolução dos gastos ao longo do mês
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={dailyData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="day" />
                      <YAxis />
                      <Tooltip formatter={(value: number) => [`R$ ${value.toFixed(2)}`, 'Gasto']} />
                      <Line 
                        type="monotone" 
                        dataKey="total" 
                        stroke="hsl(var(--primary))" 
                        strokeWidth={2}
                        dot={{ fill: 'hsl(var(--primary))' }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </motion.div>

            {/* Quick Actions */}
            <motion.div variants={fadeInUp} className="mt-8">
              <Card>
                <CardHeader>
                  <CardTitle>Ações Rápidas</CardTitle>
                  <CardDescription>
                    Acesse rapidamente as principais funcionalidades
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    <Button 
                      variant="outline" 
                      className="h-20 flex flex-col items-center justify-center"
                      onClick={() => router.push('/app/transactions')}
                    >
                      <Plus className="w-6 h-6 mb-2" />
                      Ver Transações
                    </Button>
                    <Button 
                      variant="outline" 
                      className="h-20 flex flex-col items-center justify-center"
                      onClick={() => router.push('/app/budgets')}
                    >
                      <Target className="w-6 h-6 mb-2" />
                      Orçamentos
                    </Button>
                    <Button 
                      variant="outline" 
                      className="h-20 flex flex-col items-center justify-center"
                      onClick={() => router.push('/app/categories')}
                    >
                      <PieChart className="w-6 h-6 mb-2" />
                      Categorias
                    </Button>
                    <Button 
                      variant="outline" 
                      className="h-20 flex flex-col items-center justify-center"
                      onClick={() => router.push('/about')}
                    >
                      <DollarSign className="w-6 h-6 mb-2" />
                      Sobre
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </>
  );
}