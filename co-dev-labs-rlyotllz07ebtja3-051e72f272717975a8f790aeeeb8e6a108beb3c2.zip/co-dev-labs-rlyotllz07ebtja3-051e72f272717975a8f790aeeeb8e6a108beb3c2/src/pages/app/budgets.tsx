import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import { motion } from 'framer-motion';
import { useAuth } from '@/contexts/AuthContext';
import { useExpense } from '@/contexts/ExpenseContext';
import Header from '@/components/Header';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { 
  Target,
  Plus,
  Edit,
  Trash2,
  AlertTriangle,
  CheckCircle,
  TrendingUp,
  DollarSign
} from 'lucide-react';
import { format, startOfMonth, endOfMonth, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { toast } from 'sonner';

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.5 }
};

const staggerContainer = {
  animate: {
    transition: {
      staggerChildren: 0.1
    }
  }
};

export default function Budgets() {
  const router = useRouter();
  const { user, isGuest } = useAuth();
  const { transactions, categories, budgets, setBudget } = useExpense();
  
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [editingBudget, setEditingBudget] = useState<any>(null);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [budgetAmount, setBudgetAmount] = useState('');

  // Redirect if not authenticated
  useEffect(() => {
    if (!user && !isGuest) {
      router.push('/');
    }
  }, [user, isGuest, router]);

  if (!user && !isGuest) {
    return null;
  }

  // Calculate current month spending by category
  const currentDate = new Date();
  const currentMonthStart = startOfMonth(currentDate);
  const currentMonthEnd = endOfMonth(currentDate);

  const currentMonthTransactions = transactions.filter(t => {
    const transactionDate = parseISO(t.date);
    return transactionDate >= currentMonthStart && transactionDate <= currentMonthEnd;
  });

  const categorySpending = currentMonthTransactions.reduce((acc, t) => {
    acc[t.category] = (acc[t.category] || 0) + t.amount;
    return acc;
  }, {} as Record<string, number>);

  // Create budget data with spending information
  const budgetData = categories.map(category => {
    const budget = budgets.find(b => b.categoryId === category.id);
    const spent = categorySpending[category.name] || 0;
    const limit = budget?.monthlyLimit || 0;
    const percentage = limit > 0 ? (spent / limit) * 100 : 0;
    
    return {
      category,
      budget,
      spent,
      limit,
      percentage,
      remaining: Math.max(0, limit - spent),
      status: percentage > 100 ? 'over' : percentage > 80 ? 'warning' : 'good'
    };
  });

  // Sort by percentage (highest first)
  const sortedBudgetData = [...budgetData].sort((a, b) => b.percentage - a.percentage);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedCategory || !budgetAmount) {
      toast.error('Preencha todos os campos');
      return;
    }

    const amount = parseFloat(budgetAmount.replace(',', '.'));
    if (isNaN(amount) || amount <= 0) {
      toast.error('Valor inválido');
      return;
    }

    const category = categories.find(c => c.name === selectedCategory);
    if (!category) {
      toast.error('Categoria não encontrada');
      return;
    }

    setBudget(category.id, amount);
    
    if (editingBudget) {
      toast.success('Orçamento atualizado com sucesso!');
      setIsEditOpen(false);
      setEditingBudget(null);
    } else {
      toast.success('Orçamento definido com sucesso!');
      setIsAddOpen(false);
    }

    // Reset form
    setSelectedCategory('');
    setBudgetAmount('');
  };

  const handleEdit = (budgetItem: any) => {
    setEditingBudget(budgetItem);
    setSelectedCategory(budgetItem.category.name);
    setBudgetAmount(budgetItem.limit.toString());
    setIsEditOpen(true);
  };

  const handleDelete = (categoryId: string) => {
    if (confirm('Tem certeza que deseja remover este orçamento?')) {
      setBudget(categoryId, 0);
      toast.success('Orçamento removido com sucesso!');
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'over':
        return 'text-red-600 dark:text-red-400';
      case 'warning':
        return 'text-orange-600 dark:text-orange-400';
      default:
        return 'text-green-600 dark:text-green-400';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'over':
        return <AlertTriangle className="w-4 h-4 text-red-600 dark:text-red-400" />;
      case 'warning':
        return <TrendingUp className="w-4 h-4 text-orange-600 dark:text-orange-400" />;
      default:
        return <CheckCircle className="w-4 h-4 text-green-600 dark:text-green-400" />;
    }
  };

  const getProgressColor = (percentage: number) => {
    if (percentage > 100) return 'bg-red-500';
    if (percentage > 80) return 'bg-orange-500';
    return 'bg-green-500';
  };

  const totalBudget = budgetData.reduce((sum, item) => sum + item.limit, 0);
  const totalSpent = budgetData.reduce((sum, item) => sum + item.spent, 0);
  const totalRemaining = Math.max(0, totalBudget - totalSpent);
  const overallPercentage = totalBudget > 0 ? (totalSpent / totalBudget) * 100 : 0;

  return (
    <>
      <Head>
        <title>Orçamentos - Controle de Gastos</title>
        <meta name="description" content="Gerencie seus orçamentos mensais por categoria" />
      </Head>

      <div className="bg-background min-h-screen">
        <Header />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <motion.div
            initial="initial"
            animate="animate"
            variants={staggerContainer}
          >
            {/* Header */}
            <motion.div variants={fadeInUp} className="mb-8">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                  <h1 className="text-3xl font-bold text-primary">Orçamentos</h1>
                  <p className="text-muted-foreground">
                    Defina e acompanhe seus limites de gastos por categoria
                  </p>
                </div>
                
                <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
                  <DialogTrigger asChild>
                    <Button className="flex items-center gap-2">
                      <Plus className="w-4 h-4" />
                      Novo Orçamento
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Novo Orçamento</DialogTitle>
                      <DialogDescription>
                        Defina um limite mensal para uma categoria
                      </DialogDescription>
                    </DialogHeader>
                    
                    <form onSubmit={handleSubmit} className="space-y-4">
                      <div>
                        <Label htmlFor="category">Categoria</Label>
                        <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione uma categoria" />
                          </SelectTrigger>
                          <SelectContent>
                            {categories.map(category => (
                              <SelectItem key={category.id} value={category.name}>
                                {category.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div>
                        <Label htmlFor="amount">Limite Mensal (R$)</Label>
                        <Input
                          id="amount"
                          type="text"
                          placeholder="0,00"
                          value={budgetAmount}
                          onChange={(e) => setBudgetAmount(e.target.value)}
                          required
                        />
                      </div>
                      
                      <DialogFooter>
                        <Button type="button" variant="outline" onClick={() => setIsAddOpen(false)}>
                          Cancelar
                        </Button>
                        <Button type="submit">
                          Definir Orçamento
                        </Button>
                      </DialogFooter>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>
            </motion.div>

            {/* Overall Summary */}
            <motion.div variants={fadeInUp} className="mb-8">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Target className="w-5 h-5 mr-2" />
                    Resumo Geral - {format(currentDate, 'MMMM yyyy', { locale: ptBR })}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-primary">R$ {totalBudget.toFixed(2)}</div>
                      <div className="text-sm text-muted-foreground">Orçamento Total</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold">R$ {totalSpent.toFixed(2)}</div>
                      <div className="text-sm text-muted-foreground">Gasto Total</div>
                    </div>
                    <div className="text-center">
                      <div className={`text-2xl font-bold ${totalRemaining > 0 ? 'text-green-600' : 'text-red-600'}`}>
                        R$ {totalRemaining.toFixed(2)}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {totalRemaining > 0 ? 'Disponível' : 'Excedido'}
                      </div>
                    </div>
                    <div className="text-center">
                      <div className={`text-2xl font-bold ${getStatusColor(overallPercentage > 100 ? 'over' : overallPercentage > 80 ? 'warning' : 'good')}`}>
                        {overallPercentage.toFixed(1)}%
                      </div>
                      <div className="text-sm text-muted-foreground">Utilizado</div>
                    </div>
                  </div>
                  
                  {totalBudget > 0 && (
                    <div className="mt-6">
                      <div className="flex justify-between text-sm mb-2">
                        <span>Progresso Geral</span>
                        <span>{overallPercentage.toFixed(1)}%</span>
                      </div>
                      <Progress 
                        value={Math.min(overallPercentage, 100)} 
                        className="h-3"
                      />
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>

            {/* Budget Cards */}
            <motion.div variants={fadeInUp}>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {sortedBudgetData.map((item) => (
                  <Card key={item.category.id} className={`${item.status === 'over' ? 'border-red-200 dark:border-red-800' : item.status === 'warning' ? 'border-orange-200 dark:border-orange-800' : ''}`}>
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg flex items-center">
                          <div 
                            className="w-3 h-3 rounded-full mr-2" 
                            style={{ backgroundColor: item.category.color }}
                          />
                          {item.category.name}
                        </CardTitle>
                        <div className="flex items-center gap-1">
                          {getStatusIcon(item.status)}
                          {item.budget && (
                            <div className="flex gap-1">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleEdit(item)}
                              >
                                <Edit className="w-3 h-3" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleDelete(item.category.id)}
                                className="text-destructive hover:text-destructive"
                              >
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                    </CardHeader>
                    
                    <CardContent>
                      {item.budget ? (
                        <div className="space-y-4">
                          <div className="flex justify-between items-center">
                            <div>
                              <div className="text-2xl font-bold">R$ {item.spent.toFixed(2)}</div>
                              <div className="text-sm text-muted-foreground">
                                de R$ {item.limit.toFixed(2)}
                              </div>
                            </div>
                            <Badge 
                              variant={item.status === 'over' ? 'destructive' : item.status === 'warning' ? 'secondary' : 'default'}
                            >
                              {item.percentage.toFixed(0)}%
                            </Badge>
                          </div>
                          
                          <div>
                            <div className="flex justify-between text-sm mb-2">
                              <span>Progresso</span>
                              <span className={getStatusColor(item.status)}>
                                {item.status === 'over' ? 'Excedido' : item.status === 'warning' ? 'Atenção' : 'No limite'}
                              </span>
                            </div>
                            <Progress 
                              value={Math.min(item.percentage, 100)} 
                              className="h-2"
                            />
                          </div>
                          
                          <div className="text-sm text-muted-foreground">
                            {item.remaining > 0 ? (
                              <>Restam R$ {item.remaining.toFixed(2)} este mês</>
                            ) : (
                              <>Excedeu em R$ {Math.abs(item.remaining).toFixed(2)}</>
                            )}
                          </div>
                        </div>
                      ) : (
                        <div className="text-center py-6">
                          <DollarSign className="w-8 h-8 mx-auto text-muted-foreground mb-2" />
                          <p className="text-sm text-muted-foreground mb-4">
                            Nenhum orçamento definido para esta categoria
                          </p>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => {
                              setSelectedCategory(item.category.name);
                              setIsAddOpen(true);
                            }}
                          >
                            <Plus className="w-3 h-3 mr-1" />
                            Definir Orçamento
                          </Button>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </motion.div>

            {/* Edit Dialog */}
            <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Editar Orçamento</DialogTitle>
                  <DialogDescription>
                    Modifique o limite mensal para esta categoria
                  </DialogDescription>
                </DialogHeader>
                
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="edit-category">Categoria</Label>
                    <Select value={selectedCategory} onValueChange={setSelectedCategory} disabled>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map(category => (
                          <SelectItem key={category.id} value={category.name}>
                            {category.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="edit-amount">Limite Mensal (R$)</Label>
                    <Input
                      id="edit-amount"
                      type="text"
                      placeholder="0,00"
                      value={budgetAmount}
                      onChange={(e) => setBudgetAmount(e.target.value)}
                      required
                    />
                  </div>
                  
                  <DialogFooter>
                    <Button type="button" variant="outline" onClick={() => setIsEditOpen(false)}>
                      Cancelar
                    </Button>
                    <Button type="submit">
                      Salvar
                    </Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          </motion.div>
        </div>
      </div>
    </>
  );
}