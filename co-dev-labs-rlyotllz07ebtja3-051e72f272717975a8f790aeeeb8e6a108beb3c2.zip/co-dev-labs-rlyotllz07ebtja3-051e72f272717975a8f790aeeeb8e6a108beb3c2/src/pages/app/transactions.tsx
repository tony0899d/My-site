import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import { motion } from 'framer-motion';
import { useAuth } from '@/contexts/AuthContext';
import { useExpense, Transaction } from '@/contexts/ExpenseContext';
import Header from '@/components/Header';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { 
  Plus,
  Search,
  Filter,
  Download,
  Upload,
  Edit,
  Trash2,
  Calendar,
  DollarSign,
  Tag,
  FileText
} from 'lucide-react';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { toast } from 'sonner';
import * as XLSX from 'xlsx';

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.5 }
};

const staggerContainer = {
  animate: {
    transition: {
      staggerChildren: 0.1
    }
  }
};

export default function Transactions() {
  const router = useRouter();
  const { user, isGuest } = useAuth();
  const { transactions, categories, addTransaction, updateTransaction, deleteTransaction, exportData } = useExpense();
  
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState('');
  const [filterDateFrom, setFilterDateFrom] = useState('');
  const [filterDateTo, setFilterDateTo] = useState('');
  const [filterMinAmount, setFilterMinAmount] = useState('');
  const [filterMaxAmount, setFilterMaxAmount] = useState('');

  // Form states
  const [formData, setFormData] = useState({
    date: format(new Date(), 'yyyy-MM-dd'),
    category: '',
    subcategory: '',
    description: '',
    paymentMethod: 'Dinheiro',
    amount: '',
    tags: ''
  });

  // Redirect if not authenticated
  useEffect(() => {
    if (!user && !isGuest) {
      router.push('/');
    }
  }, [user, isGuest, router]);

  if (!user && !isGuest) {
    return null;
  }

  // Filter transactions
  const filteredTransactions = transactions.filter(transaction => {
    const matchesSearch = transaction.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         transaction.category.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCategory = !filterCategory || transaction.category === filterCategory;
    
    const transactionDate = parseISO(transaction.date);
    const matchesDateFrom = !filterDateFrom || transactionDate >= parseISO(filterDateFrom);
    const matchesDateTo = !filterDateTo || transactionDate <= parseISO(filterDateTo);
    
    const matchesMinAmount = !filterMinAmount || transaction.amount >= parseFloat(filterMinAmount);
    const matchesMaxAmount = !filterMaxAmount || transaction.amount <= parseFloat(filterMaxAmount);
    
    return matchesSearch && matchesCategory && matchesDateFrom && matchesDateTo && matchesMinAmount && matchesMaxAmount;
  });

  // Sort transactions by date (newest first)
  const sortedTransactions = [...filteredTransactions].sort((a, b) => 
    new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.amount || !formData.category || !formData.description) {
      toast.error('Preencha todos os campos obrigatórios');
      return;
    }

    const amount = parseFloat(formData.amount.replace(',', '.'));
    if (isNaN(amount) || amount <= 0) {
      toast.error('Valor inválido');
      return;
    }

    const transactionData = {
      date: formData.date,
      category: formData.category,
      subcategory: formData.subcategory || undefined,
      description: formData.description,
      paymentMethod: formData.paymentMethod,
      amount,
      tags: formData.tags ? formData.tags.split(',').map(tag => tag.trim()) : []
    };

    if (editingTransaction) {
      updateTransaction(editingTransaction.id, transactionData);
      toast.success('Transação atualizada com sucesso!');
      setIsEditOpen(false);
      setEditingTransaction(null);
    } else {
      addTransaction(transactionData);
      toast.success('Transação adicionada com sucesso!');
      setIsAddOpen(false);
    }

    // Reset form
    setFormData({
      date: format(new Date(), 'yyyy-MM-dd'),
      category: '',
      subcategory: '',
      description: '',
      paymentMethod: 'Dinheiro',
      amount: '',
      tags: ''
    });
  };

  const handleEdit = (transaction: Transaction) => {
    setEditingTransaction(transaction);
    setFormData({
      date: transaction.date,
      category: transaction.category,
      subcategory: transaction.subcategory || '',
      description: transaction.description,
      paymentMethod: transaction.paymentMethod,
      amount: transaction.amount.toString(),
      tags: transaction.tags.join(', ')
    });
    setIsEditOpen(true);
  };

  const handleDelete = (id: string) => {
    if (confirm('Tem certeza que deseja excluir esta transação?')) {
      deleteTransaction(id);
      toast.success('Transação excluída com sucesso!');
    }
  };

  const handleExportCSV = () => {
    const csvData = sortedTransactions.map(t => ({
      Data: format(parseISO(t.date), 'dd/MM/yyyy'),
      Categoria: t.category,
      Subcategoria: t.subcategory || '',
      Descrição: t.description,
      'Forma de Pagamento': t.paymentMethod,
      Valor: t.amount.toFixed(2).replace('.', ','),
      Tags: t.tags.join(', '),
      'Criado em': format(parseISO(t.createdAt), 'dd/MM/yyyy HH:mm')
    }));

    const ws = XLSX.utils.json_to_sheet(csvData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Transações');
    XLSX.writeFile(wb, `transacoes-${format(new Date(), 'yyyy-MM-dd')}.xlsx`);
    toast.success('Arquivo exportado com sucesso!');
  };

  const handleImportCSV = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet);

        let importedCount = 0;
        jsonData.forEach((row: any) => {
          try {
            const amount = parseFloat(row.Valor?.toString().replace(',', '.') || '0');
            if (amount > 0 && row.Descrição && row.Categoria) {
              addTransaction({
                date: row.Data ? format(new Date(row.Data), 'yyyy-MM-dd') : format(new Date(), 'yyyy-MM-dd'),
                category: row.Categoria,
                subcategory: row.Subcategoria || undefined,
                description: row.Descrição,
                paymentMethod: row['Forma de Pagamento'] || 'Dinheiro',
                amount,
                tags: row.Tags ? row.Tags.split(',').map((tag: string) => tag.trim()) : []
              });
              importedCount++;
            }
          } catch (error) {
            console.error('Erro ao importar linha:', row, error);
          }
        });

        toast.success(`${importedCount} transações importadas com sucesso!`);
      } catch (error) {
        toast.error('Erro ao importar arquivo. Verifique o formato.');
      }
    };
    reader.readAsArrayBuffer(file);
    
    // Reset input
    event.target.value = '';
  };

  const clearFilters = () => {
    setSearchTerm('');
    setFilterCategory('');
    setFilterDateFrom('');
    setFilterDateTo('');
    setFilterMinAmount('');
    setFilterMaxAmount('');
  };

  const selectedCategory = categories.find(c => c.name === formData.category);

  return (
    <>
      <Head>
        <title>Transações - Controle de Gastos</title>
        <meta name="description" content="Gerencie suas transações e gastos pessoais" />
      </Head>

      <div className="bg-background min-h-screen">
        <Header />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <motion.div
            initial="initial"
            animate="animate"
            variants={staggerContainer}
          >
            {/* Header */}
            <motion.div variants={fadeInUp} className="mb-8">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                  <h1 className="text-3xl font-bold text-primary">Transações</h1>
                  <p className="text-muted-foreground">
                    Gerencie todos os seus gastos e receitas
                  </p>
                </div>
                
                <div className="flex flex-col sm:flex-row gap-2">
                  {/* Import Button */}
                  <div className="relative">
                    <input
                      type="file"
                      accept=".xlsx,.xls,.csv"
                      onChange={handleImportCSV}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    />
                    <Button variant="outline" className="flex items-center gap-2">
                      <Upload className="w-4 h-4" />
                      Importar
                    </Button>
                  </div>
                  
                  {/* Export Button */}
                  <Button variant="outline" onClick={handleExportCSV} className="flex items-center gap-2">
                    <Download className="w-4 h-4" />
                    Exportar
                  </Button>
                  
                  {/* Add Transaction Button */}
                  <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
                    <DialogTrigger asChild>
                      <Button className="flex items-center gap-2">
                        <Plus className="w-4 h-4" />
                        Nova Transação
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
                      <DialogHeader>
                        <DialogTitle>Nova Transação</DialogTitle>
                        <DialogDescription>
                          Adicione uma nova transação aos seus registros
                        </DialogDescription>
                      </DialogHeader>
                      
                      <form onSubmit={handleSubmit} className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="date">Data</Label>
                            <Input
                              id="date"
                              type="date"
                              value={formData.date}
                              onChange={(e) => setFormData(prev => ({ ...prev, date: e.target.value }))}
                              required
                            />
                          </div>
                          
                          <div>
                            <Label htmlFor="amount">Valor (R$)</Label>
                            <Input
                              id="amount"
                              type="text"
                              placeholder="0,00"
                              value={formData.amount}
                              onChange={(e) => setFormData(prev => ({ ...prev, amount: e.target.value }))}
                              required
                            />
                          </div>
                        </div>
                        
                        <div>
                          <Label htmlFor="category">Categoria</Label>
                          <Select 
                            value={formData.category} 
                            onValueChange={(value) => setFormData(prev => ({ ...prev, category: value, subcategory: '' }))}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Selecione uma categoria" />
                            </SelectTrigger>
                            <SelectContent>
                              {categories.map(category => (
                                <SelectItem key={category.id} value={category.name}>
                                  {category.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        
                        {selectedCategory && selectedCategory.subcategories.length > 0 && (
                          <div>
                            <Label htmlFor="subcategory">Subcategoria</Label>
                            <Select 
                              value={formData.subcategory} 
                              onValueChange={(value) => setFormData(prev => ({ ...prev, subcategory: value }))}
                            >
                              <SelectTrigger>
                                <SelectValue placeholder="Selecione uma subcategoria" />
                              </SelectTrigger>
                              <SelectContent>
                                {selectedCategory.subcategories.map(sub => (
                                  <SelectItem key={sub} value={sub}>
                                    {sub}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        )}
                        
                        <div>
                          <Label htmlFor="description">Descrição</Label>
                          <Textarea
                            id="description"
                            placeholder="Descreva o gasto..."
                            value={formData.description}
                            onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                            required
                          />
                        </div>
                        
                        <div>
                          <Label htmlFor="paymentMethod">Forma de Pagamento</Label>
                          <Select 
                            value={formData.paymentMethod} 
                            onValueChange={(value) => setFormData(prev => ({ ...prev, paymentMethod: value }))}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Dinheiro">Dinheiro</SelectItem>
                              <SelectItem value="Cartão de Débito">Cartão de Débito</SelectItem>
                              <SelectItem value="Cartão de Crédito">Cartão de Crédito</SelectItem>
                              <SelectItem value="PIX">PIX</SelectItem>
                              <SelectItem value="Transferência">Transferência</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        
                        <div>
                          <Label htmlFor="tags">Tags (separadas por vírgula)</Label>
                          <Input
                            id="tags"
                            type="text"
                            placeholder="urgente, trabalho, pessoal"
                            value={formData.tags}
                            onChange={(e) => setFormData(prev => ({ ...prev, tags: e.target.value }))}
                          />
                        </div>
                        
                        <DialogFooter>
                          <Button type="button" variant="outline" onClick={() => setIsAddOpen(false)}>
                            Cancelar
                          </Button>
                          <Button type="submit">
                            Adicionar
                          </Button>
                        </DialogFooter>
                      </form>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>
            </motion.div>

            {/* Filters */}
            <motion.div variants={fadeInUp} className="mb-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Filter className="w-5 h-5 mr-2" />
                    Filtros
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
                    <div>
                      <Label htmlFor="search">Buscar</Label>
                      <div className="relative">
                        <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                        <Input
                          id="search"
                          placeholder="Descrição ou categoria..."
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                          className="pl-10"
                        />
                      </div>
                    </div>
                    
                    <div>
                      <Label htmlFor="filterCategory">Categoria</Label>
                      <Select value={filterCategory} onValueChange={setFilterCategory}>
                        <SelectTrigger>
                          <SelectValue placeholder="Todas" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="">Todas</SelectItem>
                          {categories.map(category => (
                            <SelectItem key={category.id} value={category.name}>
                              {category.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <Label htmlFor="dateFrom">Data de</Label>
                      <Input
                        id="dateFrom"
                        type="date"
                        value={filterDateFrom}
                        onChange={(e) => setFilterDateFrom(e.target.value)}
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="dateTo">Data até</Label>
                      <Input
                        id="dateTo"
                        type="date"
                        value={filterDateTo}
                        onChange={(e) => setFilterDateTo(e.target.value)}
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="minAmount">Valor mín.</Label>
                      <Input
                        id="minAmount"
                        type="number"
                        placeholder="0,00"
                        value={filterMinAmount}
                        onChange={(e) => setFilterMinAmount(e.target.value)}
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="maxAmount">Valor máx.</Label>
                      <Input
                        id="maxAmount"
                        type="number"
                        placeholder="0,00"
                        value={filterMaxAmount}
                        onChange={(e) => setFilterMaxAmount(e.target.value)}
                      />
                    </div>
                  </div>
                  
                  <div className="mt-4 flex justify-between items-center">
                    <p className="text-sm text-muted-foreground">
                      {sortedTransactions.length} transação(ões) encontrada(s)
                    </p>
                    <Button variant="outline" size="sm" onClick={clearFilters}>
                      Limpar Filtros
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Transactions Table */}
            <motion.div variants={fadeInUp}>
              <Card>
                <CardHeader>
                  <CardTitle>Lista de Transações</CardTitle>
                  <CardDescription>
                    Todas as suas transações organizadas por data
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {sortedTransactions.length > 0 ? (
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Data</TableHead>
                            <TableHead>Categoria</TableHead>
                            <TableHead>Descrição</TableHead>
                            <TableHead>Pagamento</TableHead>
                            <TableHead className="text-right">Valor</TableHead>
                            <TableHead>Tags</TableHead>
                            <TableHead className="text-right">Ações</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {sortedTransactions.map((transaction) => (
                            <TableRow key={transaction.id}>
                              <TableCell>
                                <div className="flex items-center">
                                  <Calendar className="w-4 h-4 mr-2 text-muted-foreground" />
                                  {format(parseISO(transaction.date), 'dd/MM/yyyy')}
                                </div>
                              </TableCell>
                              <TableCell>
                                <div>
                                  <div className="font-medium">{transaction.category}</div>
                                  {transaction.subcategory && (
                                    <div className="text-sm text-muted-foreground">
                                      {transaction.subcategory}
                                    </div>
                                  )}
                                </div>
                              </TableCell>
                              <TableCell>
                                <div className="max-w-xs truncate" title={transaction.description}>
                                  {transaction.description}
                                </div>
                              </TableCell>
                              <TableCell>
                                <Badge variant="outline">
                                  {transaction.paymentMethod}
                                </Badge>
                              </TableCell>
                              <TableCell className="text-right font-medium">
                                R$ {transaction.amount.toFixed(2)}
                              </TableCell>
                              <TableCell>
                                <div className="flex flex-wrap gap-1">
                                  {transaction.tags.map((tag, index) => (
                                    <Badge key={index} variant="secondary" className="text-xs">
                                      {tag}
                                    </Badge>
                                  ))}
                                </div>
                              </TableCell>
                              <TableCell className="text-right">
                                <div className="flex justify-end gap-2">
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => handleEdit(transaction)}
                                  >
                                    <Edit className="w-4 h-4" />
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => handleDelete(transaction.id)}
                                    className="text-destructive hover:text-destructive"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <FileText className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                      <h3 className="text-lg font-medium text-muted-foreground mb-2">
                        Nenhuma transação encontrada
                      </h3>
                      <p className="text-muted-foreground mb-4">
                        {searchTerm || filterCategory || filterDateFrom || filterDateTo || filterMinAmount || filterMaxAmount
                          ? 'Tente ajustar os filtros ou limpar a busca'
                          : 'Comece adicionando sua primeira transação'
                        }
                      </p>
                      <Button onClick={() => setIsAddOpen(true)}>
                        <Plus className="w-4 h-4 mr-2" />
                        Adicionar Transação
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>

            {/* Edit Dialog */}
            <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
              <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Editar Transação</DialogTitle>
                  <DialogDescription>
                    Modifique os dados da transação
                  </DialogDescription>
                </DialogHeader>
                
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="edit-date">Data</Label>
                      <Input
                        id="edit-date"
                        type="date"
                        value={formData.date}
                        onChange={(e) => setFormData(prev => ({ ...prev, date: e.target.value }))}
                        required
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="edit-amount">Valor (R$)</Label>
                      <Input
                        id="edit-amount"
                        type="text"
                        placeholder="0,00"
                        value={formData.amount}
                        onChange={(e) => setFormData(prev => ({ ...prev, amount: e.target.value }))}
                        required
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="edit-category">Categoria</Label>
                    <Select 
                      value={formData.category} 
                      onValueChange={(value) => setFormData(prev => ({ ...prev, category: value, subcategory: '' }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione uma categoria" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map(category => (
                          <SelectItem key={category.id} value={category.name}>
                            {category.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  {selectedCategory && selectedCategory.subcategories.length > 0 && (
                    <div>
                      <Label htmlFor="edit-subcategory">Subcategoria</Label>
                      <Select 
                        value={formData.subcategory} 
                        onValueChange={(value) => setFormData(prev => ({ ...prev, subcategory: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione uma subcategoria" />
                        </SelectTrigger>
                        <SelectContent>
                          {selectedCategory.subcategories.map(sub => (
                            <SelectItem key={sub} value={sub}>
                              {sub}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                  
                  <div>
                    <Label htmlFor="edit-description">Descrição</Label>
                    <Textarea
                      id="edit-description"
                      placeholder="Descreva o gasto..."
                      value={formData.description}
                      onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                      required
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="edit-paymentMethod">Forma de Pagamento</Label>
                    <Select 
                      value={formData.paymentMethod} 
                      onValueChange={(value) => setFormData(prev => ({ ...prev, paymentMethod: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Dinheiro">Dinheiro</SelectItem>
                        <SelectItem value="Cartão de Débito">Cartão de Débito</SelectItem>
                        <SelectItem value="Cartão de Crédito">Cartão de Crédito</SelectItem>
                        <SelectItem value="PIX">PIX</SelectItem>
                        <SelectItem value="Transferência">Transferência</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="edit-tags">Tags (separadas por vírgula)</Label>
                    <Input
                      id="edit-tags"
                      type="text"
                      placeholder="urgente, trabalho, pessoal"
                      value={formData.tags}
                      onChange={(e) => setFormData(prev => ({ ...prev, tags: e.target.value }))}
                    />
                  </div>
                  
                  <DialogFooter>
                    <Button type="button" variant="outline" onClick={() => setIsEditOpen(false)}>
                      Cancelar
                    </Button>
                    <Button type="submit">
                      Salvar
                    </Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          </motion.div>
        </div>
      </div>
    </>
  );
}