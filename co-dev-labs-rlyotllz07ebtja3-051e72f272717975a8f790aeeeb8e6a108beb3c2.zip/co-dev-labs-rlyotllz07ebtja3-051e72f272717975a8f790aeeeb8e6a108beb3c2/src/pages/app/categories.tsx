import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import { motion } from 'framer-motion';
import { useAuth } from '@/contexts/AuthContext';
import { useExpense, Category } from '@/contexts/ExpenseContext';
import Header from '@/components/Header';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { 
  Plus,
  Edit,
  Trash2,
  Tag,
  Palette,
  Hash
} from 'lucide-react';
import { toast } from 'sonner';

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.5 }
};

const staggerContainer = {
  animate: {
    transition: {
      staggerChildren: 0.1
    }
  }
};

const colorOptions = [
  '#ef4444', // red
  '#f97316', // orange
  '#f59e0b', // amber
  '#eab308', // yellow
  '#84cc16', // lime
  '#22c55e', // green
  '#10b981', // emerald
  '#14b8a6', // teal
  '#06b6d4', // cyan
  '#0ea5e9', // sky
  '#3b82f6', // blue
  '#6366f1', // indigo
  '#8b5cf6', // violet
  '#a855f7', // purple
  '#d946ef', // fuchsia
  '#ec4899', // pink
  '#f43f5e', // rose
];

export default function Categories() {
  const router = useRouter();
  const { user, isGuest } = useAuth();
  const { categories, addCategory, updateCategory, deleteCategory, transactions } = useExpense();
  
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    color: colorOptions[0],
    subcategories: ''
  });

  // Redirect if not authenticated
  useEffect(() => {
    if (!user && !isGuest) {
      router.push('/');
    }
  }, [user, isGuest, router]);

  if (!user && !isGuest) {
    return null;
  }

  // Calculate usage statistics for each category
  const categoryStats = categories.map(category => {
    const categoryTransactions = transactions.filter(t => t.category === category.name);
    const totalAmount = categoryTransactions.reduce((sum, t) => sum + t.amount, 0);
    const transactionCount = categoryTransactions.length;
    
    return {
      ...category,
      totalAmount,
      transactionCount,
      lastUsed: categoryTransactions.length > 0 
        ? new Date(Math.max(...categoryTransactions.map(t => new Date(t.date).getTime())))
        : null
    };
  });

  // Sort by usage (most used first)
  const sortedCategories = [...categoryStats].sort((a, b) => b.transactionCount - a.transactionCount);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim()) {
      toast.error('Nome da categoria é obrigatório');
      return;
    }

    // Check if category name already exists (excluding current editing category)
    const existingCategory = categories.find(c => 
      c.name.toLowerCase() === formData.name.trim().toLowerCase() && 
      c.id !== editingCategory?.id
    );
    
    if (existingCategory) {
      toast.error('Já existe uma categoria com este nome');
      return;
    }

    const subcategories = formData.subcategories
      .split(',')
      .map(sub => sub.trim())
      .filter(sub => sub.length > 0);

    const categoryData = {
      name: formData.name.trim(),
      color: formData.color,
      subcategories
    };

    if (editingCategory) {
      updateCategory(editingCategory.id, categoryData);
      toast.success('Categoria atualizada com sucesso!');
      setIsEditOpen(false);
      setEditingCategory(null);
    } else {
      addCategory(categoryData);
      toast.success('Categoria criada com sucesso!');
      setIsAddOpen(false);
    }

    // Reset form
    setFormData({
      name: '',
      color: colorOptions[0],
      subcategories: ''
    });
  };

  const handleEdit = (category: Category) => {
    setEditingCategory(category);
    setFormData({
      name: category.name,
      color: category.color,
      subcategories: category.subcategories.join(', ')
    });
    setIsEditOpen(true);
  };

  const handleDelete = (categoryId: string) => {
    const category = categories.find(c => c.id === categoryId);
    if (!category) return;

    const categoryTransactions = transactions.filter(t => t.category === category.name);
    
    if (categoryTransactions.length > 0) {
      if (!confirm(`Esta categoria tem ${categoryTransactions.length} transação(ões) associada(s). Tem certeza que deseja excluí-la? As transações não serão removidas, mas ficarão sem categoria válida.`)) {
        return;
      }
    } else {
      if (!confirm('Tem certeza que deseja excluir esta categoria?')) {
        return;
      }
    }

    deleteCategory(categoryId);
    toast.success('Categoria excluída com sucesso!');
  };

  const resetForm = () => {
    setFormData({
      name: '',
      color: colorOptions[0],
      subcategories: ''
    });
    setEditingCategory(null);
  };

  return (
    <>
      <Head>
        <title>Categorias - Controle de Gastos</title>
        <meta name="description" content="Gerencie suas categorias de gastos" />
      </Head>

      <div className="bg-background min-h-screen">
        <Header />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <motion.div
            initial="initial"
            animate="animate"
            variants={staggerContainer}
          >
            {/* Header */}
            <motion.div variants={fadeInUp} className="mb-8">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                  <h1 className="text-3xl font-bold text-primary">Categorias</h1>
                  <p className="text-muted-foreground">
                    Organize seus gastos criando e personalizando categorias
                  </p>
                </div>
                
                <Dialog open={isAddOpen} onOpenChange={(open) => {
                  setIsAddOpen(open);
                  if (!open) resetForm();
                }}>
                  <DialogTrigger asChild>
                    <Button className="flex items-center gap-2">
                      <Plus className="w-4 h-4" />
                      Nova Categoria
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Nova Categoria</DialogTitle>
                      <DialogDescription>
                        Crie uma nova categoria para organizar seus gastos
                      </DialogDescription>
                    </DialogHeader>
                    
                    <form onSubmit={handleSubmit} className="space-y-4">
                      <div>
                        <Label htmlFor="name">Nome da Categoria</Label>
                        <Input
                          id="name"
                          type="text"
                          placeholder="Ex: Alimentação, Transporte..."
                          value={formData.name}
                          onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                          required
                        />
                      </div>
                      
                      <div>
                        <Label htmlFor="color">Cor</Label>
                        <div className="grid grid-cols-8 gap-2 mt-2">
                          {colorOptions.map(color => (
                            <button
                              key={color}
                              type="button"
                              className={`w-8 h-8 rounded-full border-2 ${
                                formData.color === color ? 'border-primary' : 'border-transparent'
                              }`}
                              style={{ backgroundColor: color }}
                              onClick={() => setFormData(prev => ({ ...prev, color }))}
                            />
                          ))}
                        </div>
                      </div>
                      
                      <div>
                        <Label htmlFor="subcategories">Subcategorias (opcional)</Label>
                        <Textarea
                          id="subcategories"
                          placeholder="Separe por vírgula: Supermercado, Restaurante, Lanche"
                          value={formData.subcategories}
                          onChange={(e) => setFormData(prev => ({ ...prev, subcategories: e.target.value }))}
                          rows={3}
                        />
                        <p className="text-xs text-muted-foreground mt-1">
                          As subcategorias ajudam a organizar melhor seus gastos dentro de cada categoria
                        </p>
                      </div>
                      
                      <DialogFooter>
                        <Button type="button" variant="outline" onClick={() => setIsAddOpen(false)}>
                          Cancelar
                        </Button>
                        <Button type="submit">
                          Criar Categoria
                        </Button>
                      </DialogFooter>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>
            </motion.div>

            {/* Categories Grid */}
            <motion.div variants={fadeInUp}>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {sortedCategories.map((category) => (
                  <Card key={category.id} className="hover:shadow-lg transition-shadow">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg flex items-center">
                          <div 
                            className="w-4 h-4 rounded-full mr-3" 
                            style={{ backgroundColor: category.color }}
                          />
                          {category.name}
                        </CardTitle>
                        <div className="flex gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEdit(category)}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDelete(category.id)}
                            className="text-destructive hover:text-destructive"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </CardHeader>
                    
                    <CardContent className="space-y-4">
                      {/* Statistics */}
                      <div className="grid grid-cols-2 gap-4 text-center">
                        <div>
                          <div className="text-2xl font-bold text-primary">
                            {category.transactionCount}
                          </div>
                          <div className="text-xs text-muted-foreground">Transações</div>
                        </div>
                        <div>
                          <div className="text-2xl font-bold">
                            R$ {category.totalAmount.toFixed(2)}
                          </div>
                          <div className="text-xs text-muted-foreground">Total Gasto</div>
                        </div>
                      </div>
                      
                      {/* Subcategories */}
                      {category.subcategories.length > 0 && (
                        <div>
                          <div className="text-sm font-medium mb-2 flex items-center">
                            <Hash className="w-3 h-3 mr-1" />
                            Subcategorias
                          </div>
                          <div className="flex flex-wrap gap-1">
                            {category.subcategories.map((sub, index) => (
                              <Badge key={index} variant="secondary" className="text-xs">
                                {sub}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                      
                      {/* Last used */}
                      {category.lastUsed && (
                        <div className="text-xs text-muted-foreground">
                          Último uso: {category.lastUsed.toLocaleDateString('pt-BR')}
                        </div>
                      )}
                      
                      {category.transactionCount === 0 && (
                        <div className="text-xs text-muted-foreground italic">
                          Categoria ainda não utilizada
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
              
              {categories.length === 0 && (
                <Card>
                  <CardContent className="text-center py-12">
                    <Tag className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                    <h3 className="text-lg font-medium text-muted-foreground mb-2">
                      Nenhuma categoria encontrada
                    </h3>
                    <p className="text-muted-foreground mb-4">
                      Comece criando sua primeira categoria para organizar seus gastos
                    </p>
                    <Button onClick={() => setIsAddOpen(true)}>
                      <Plus className="w-4 h-4 mr-2" />
                      Criar Primeira Categoria
                    </Button>
                  </CardContent>
                </Card>
              )}
            </motion.div>

            {/* Edit Dialog */}
            <Dialog open={isEditOpen} onOpenChange={(open) => {
              setIsEditOpen(open);
              if (!open) resetForm();
            }}>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Editar Categoria</DialogTitle>
                  <DialogDescription>
                    Modifique os dados da categoria
                  </DialogDescription>
                </DialogHeader>
                
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="edit-name">Nome da Categoria</Label>
                    <Input
                      id="edit-name"
                      type="text"
                      placeholder="Ex: Alimentação, Transporte..."
                      value={formData.name}
                      onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                      required
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="edit-color">Cor</Label>
                    <div className="grid grid-cols-8 gap-2 mt-2">
                      {colorOptions.map(color => (
                        <button
                          key={color}
                          type="button"
                          className={`w-8 h-8 rounded-full border-2 ${
                            formData.color === color ? 'border-primary' : 'border-transparent'
                          }`}
                          style={{ backgroundColor: color }}
                          onClick={() => setFormData(prev => ({ ...prev, color }))}
                        />
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="edit-subcategories">Subcategorias (opcional)</Label>
                    <Textarea
                      id="edit-subcategories"
                      placeholder="Separe por vírgula: Supermercado, Restaurante, Lanche"
                      value={formData.subcategories}
                      onChange={(e) => setFormData(prev => ({ ...prev, subcategories: e.target.value }))}
                      rows={3}
                    />
                    <p className="text-xs text-muted-foreground mt-1">
                      As subcategorias ajudam a organizar melhor seus gastos dentro de cada categoria
                    </p>
                  </div>
                  
                  <DialogFooter>
                    <Button type="button" variant="outline" onClick={() => setIsEditOpen(false)}>
                      Cancelar
                    </Button>
                    <Button type="submit">
                      Salvar Alterações
                    </Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          </motion.div>
        </div>
      </div>
    </>
  );
}