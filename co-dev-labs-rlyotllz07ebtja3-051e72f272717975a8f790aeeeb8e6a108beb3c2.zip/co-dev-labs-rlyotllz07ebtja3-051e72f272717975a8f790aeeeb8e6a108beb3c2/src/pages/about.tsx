import React from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import { motion } from 'framer-motion';
import Header from '@/components/Header';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Heart, 
  Shield, 
  Code, 
  Database, 
  Smartphone,
  Github,
  ArrowLeft
} from 'lucide-react';

const fadeInUp = {
  initial: { opacity: 0, y: 60 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 }
};

const staggerContainer = {
  animate: {
    transition: {
      staggerChildren: 0.1
    }
  }
};

export default function About() {
  const router = useRouter();

  return (
    <>
      <Head>
        <title>Sobre - Criado por Tony</title>
        <meta name="description" content="Conheça mais sobre o criador e a filosofia por trás desta ferramenta gratuita de controle de gastos" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      
      <div className="bg-background min-h-screen">
        <Header />
        
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <motion.div
            initial="initial"
            animate="animate"
            variants={staggerContainer}
          >
            <motion.div variants={fadeInUp} className="mb-8">
              <Button
                variant="ghost"
                onClick={() => router.back()}
                className="mb-6"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Voltar
              </Button>
              
              <div className="text-center mb-12">
                <Badge variant="secondary" className="mb-4">
                  <Heart className="w-3 h-3 mr-1" />
                  Feito com amor
                </Badge>
                <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">
                  Criado por Tony
                </h1>
                <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                  Uma ferramenta gratuita e privada para controle de gastos pessoais, 
                  desenvolvida com foco na simplicidade e privacidade do usuário.
                </p>
              </div>
            </motion.div>

            {/* Sobre o Projeto */}
            <motion.div variants={fadeInUp} className="mb-12">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Code className="w-5 h-5 mr-2" />
                    Sobre o Projeto
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-muted-foreground">
                    Este projeto nasceu da necessidade pessoal de ter uma ferramenta simples, 
                    rápida e privada para controlar gastos pessoais. Cansado de aplicativos 
                    complexos que exigem cadastros desnecessários ou que comprometem a privacidade 
                    dos dados, decidi criar uma solução que fosse:
                  </p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                    <div className="flex items-start space-x-3">
                      <Shield className="w-5 h-5 text-primary mt-1" />
                      <div>
                        <h3 className="font-semibold text-primary">100% Privada</h3>
                        <p className="text-sm text-muted-foreground">
                          Todos os dados ficam no seu navegador. Nada é enviado para servidores.
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-start space-x-3">
                      <Heart className="w-5 h-5 text-primary mt-1" />
                      <div>
                        <h3 className="font-semibold text-primary">Gratuita</h3>
                        <p className="text-sm text-muted-foreground">
                          Sem taxas, sem assinaturas, sem pegadinhas. Gratuita para sempre.
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-start space-x-3">
                      <Smartphone className="w-5 h-5 text-primary mt-1" />
                      <div>
                        <h3 className="font-semibold text-primary">Responsiva</h3>
                        <p className="text-sm text-muted-foreground">
                          Funciona perfeitamente em qualquer dispositivo.
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-start space-x-3">
                      <Database className="w-5 h-5 text-primary mt-1" />
                      <div>
                        <h3 className="font-semibold text-primary">Seus Dados</h3>
                        <p className="text-sm text-muted-foreground">
                          Exporte quando quiser. Importe de onde precisar.
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Tecnologias */}
            <motion.div variants={fadeInUp} className="mb-12">
              <Card>
                <CardHeader>
                  <CardTitle>Tecnologias Utilizadas</CardTitle>
                  <CardDescription>
                    Construído com tecnologias modernas e confiáveis
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="text-center p-4 border rounded-lg">
                      <div className="font-semibold text-primary">Next.js</div>
                      <div className="text-sm text-muted-foreground">Framework React</div>
                    </div>
                    <div className="text-center p-4 border rounded-lg">
                      <div className="font-semibold text-primary">TypeScript</div>
                      <div className="text-sm text-muted-foreground">Tipagem estática</div>
                    </div>
                    <div className="text-center p-4 border rounded-lg">
                      <div className="font-semibold text-primary">Tailwind CSS</div>
                      <div className="text-sm text-muted-foreground">Estilização</div>
                    </div>
                    <div className="text-center p-4 border rounded-lg">
                      <div className="font-semibold text-primary">Recharts</div>
                      <div className="text-sm text-muted-foreground">Gráficos</div>
                    </div>
                    <div className="text-center p-4 border rounded-lg">
                      <div className="font-semibold text-primary">Framer Motion</div>
                      <div className="text-sm text-muted-foreground">Animações</div>
                    </div>
                    <div className="text-center p-4 border rounded-lg">
                      <div className="font-semibold text-primary">Radix UI</div>
                      <div className="text-sm text-muted-foreground">Componentes</div>
                    </div>
                    <div className="text-center p-4 border rounded-lg">
                      <div className="font-semibold text-primary">LocalStorage</div>
                      <div className="text-sm text-muted-foreground">Armazenamento</div>
                    </div>
                    <div className="text-center p-4 border rounded-lg">
                      <div className="font-semibold text-primary">PWA Ready</div>
                      <div className="text-sm text-muted-foreground">App nativo</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Privacidade */}
            <motion.div variants={fadeInUp} className="mb-12">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Shield className="w-5 h-5 mr-2" />
                    Compromisso com a Privacidade
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-muted-foreground">
                    Sua privacidade é fundamental. Por isso, esta aplicação foi desenvolvida 
                    com os seguintes princípios:
                  </p>
                  
                  <ul className="space-y-2 text-muted-foreground">
                    <li className="flex items-start">
                      <span className="w-2 h-2 bg-primary rounded-full mt-2 mr-3 flex-shrink-0"></span>
                      <span>
                        <strong>Armazenamento local:</strong> Todos os seus dados ficam 
                        armazenados apenas no seu navegador (localStorage).
                      </span>
                    </li>
                    <li className="flex items-start">
                      <span className="w-2 h-2 bg-primary rounded-full mt-2 mr-3 flex-shrink-0"></span>
                      <span>
                        <strong>Sem servidores:</strong> Não enviamos nenhum dado para 
                        servidores externos. Tudo funciona offline.
                      </span>
                    </li>
                    <li className="flex items-start">
                      <span className="w-2 h-2 bg-primary rounded-full mt-2 mr-3 flex-shrink-0"></span>
                      <span>
                        <strong>Sem tracking:</strong> Não coletamos informações de uso, 
                        não temos analytics, não temos cookies de terceiros.
                      </span>
                    </li>
                    <li className="flex items-start">
                      <span className="w-2 h-2 bg-primary rounded-full mt-2 mr-3 flex-shrink-0"></span>
                      <span>
                        <strong>Código aberto:</strong> O código está disponível para 
                        auditoria e contribuições.
                      </span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </motion.div>

            {/* Contato */}
            <motion.div variants={fadeInUp}>
              <Card>
                <CardHeader>
                  <CardTitle>Contato e Contribuições</CardTitle>
                  <CardDescription>
                    Tem sugestões, encontrou bugs ou quer contribuir?
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-muted-foreground">
                    Este é um projeto de código aberto e toda contribuição é bem-vinda! 
                    Se você encontrou algum problema, tem sugestões de melhorias ou quer 
                    contribuir com código, ficarei feliz em receber seu feedback.
                  </p>
                  
                  <div className="flex flex-col sm:flex-row gap-4">
                    <Button variant="outline" className="flex items-center">
                      <Github className="w-4 h-4 mr-2" />
                      Ver no GitHub
                    </Button>
                    <Button variant="outline">
                      Reportar Bug
                    </Button>
                    <Button variant="outline">
                      Sugerir Funcionalidade
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </motion.div>
        </div>

        {/* Footer */}
        <footer className="border-t border-border py-8 mt-12">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center text-muted-foreground">
              <p className="mb-2">
                <span className="font-semibold text-primary">Criado por Tony</span> com 
                <Heart className="w-4 h-4 inline mx-1 text-red-500" />
                para a comunidade
              </p>
              <p className="text-sm">
                Gratuito para sempre • Privado por design • Código aberto
              </p>
            </div>
          </div>
        </footer>
      </div>
    </>
  );
}