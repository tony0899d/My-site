import React from "react";
import Head from "next/head";
import { useRouter } from "next/router";
import { motion } from "framer-motion";
import { useAuth } from "@/contexts/AuthContext";
import Header from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  TrendingUp, 
  PieChart, 
  BarChart3, 
  Wallet, 
  Target, 
  Download,
  Zap,
  Shield,
  Smartphone
} from "lucide-react";

const fadeInUp = {
  initial: { opacity: 0, y: 60 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 }
};

const staggerContainer = {
  animate: {
    transition: {
      staggerChildren: 0.1
    }
  }
};

export default function Home() {
  const router = useRouter();
  const { user, isGuest, loginAsGuest } = useAuth();

  // Redirect authenticated users to dashboard
  React.useEffect(() => {
    if (user || isGuest) {
      router.push('/app');
    }
  }, [user, isGuest, router]);

  const handleGetStarted = () => {
    router.push('/auth/register');
  };

  const handleLogin = () => {
    router.push('/auth/login');
  };

  const handleGuestMode = () => {
    loginAsGuest();
    router.push('/app');
  };

  return (
    <>
      <Head>
        <title>Controle de Gastos - Criado por Tony</title>
        <meta name="description" content="Controle seus gastos pessoais de forma simples e gratuita. Criado por Tony." />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      
      <div className="bg-background min-h-screen">
        <Header />
        
        {/* Hero Section */}
        <section className="relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-secondary/5" />
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
            <motion.div 
              className="text-center"
              initial="initial"
              animate="animate"
              variants={staggerContainer}
            >
              <motion.div variants={fadeInUp}>
                <Badge variant="secondary" className="mb-4">
                  <Zap className="w-3 h-3 mr-1" />
                  Gratuito e Privado
                </Badge>
              </motion.div>
              
              <motion.h1 
                className="text-4xl md:text-6xl font-bold text-primary mb-6"
                variants={fadeInUp}
              >
                Controle seus gastos
                <br />
                <span className="text-muted-foreground">de forma simples</span>
              </motion.h1>
              
              <motion.p 
                className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto"
                variants={fadeInUp}
              >
                Organize suas finanças pessoais com gráficos bonitos, relatórios detalhados 
                e controle total dos seus dados. Tudo gratuito e privado.
              </motion.p>
              
              <motion.div 
                className="flex flex-col sm:flex-row gap-4 justify-center items-center"
                variants={fadeInUp}
              >
                <Button size="lg" onClick={handleGetStarted} className="w-full sm:w-auto">
                  Começar Agora
                </Button>
                <Button variant="outline" size="lg" onClick={handleLogin} className="w-full sm:w-auto">
                  Já tenho conta
                </Button>
                <Button variant="ghost" size="lg" onClick={handleGuestMode} className="w-full sm:w-auto">
                  Testar como visitante
                </Button>
              </motion.div>
            </motion.div>
          </div>
        </section>

        {/* Features Preview */}
        <section className="py-20 bg-muted/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div 
              className="text-center mb-16"
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
              variants={fadeInUp}
            >
              <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">
                Tudo que você precisa
              </h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Funcionalidades completas para controle financeiro pessoal
              </p>
            </motion.div>

            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
              variants={staggerContainer}
            >
              <motion.div variants={fadeInUp}>
                <Card className="h-full hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                      <Zap className="w-6 h-6 text-primary" />
                    </div>
                    <CardTitle>Lançamento Rápido</CardTitle>
                    <CardDescription>
                      Adicione gastos em menos de 3 cliques com o botão "Gastei hoje"
                    </CardDescription>
                  </CardHeader>
                </Card>
              </motion.div>

              <motion.div variants={fadeInUp}>
                <Card className="h-full hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                      <PieChart className="w-6 h-6 text-primary" />
                    </div>
                    <CardTitle>Gráficos Bonitos</CardTitle>
                    <CardDescription>
                      Visualize seus gastos com gráficos interativos e animações suaves
                    </CardDescription>
                  </CardHeader>
                </Card>
              </motion.div>

              <motion.div variants={fadeInUp}>
                <Card className="h-full hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                      <Target className="w-6 h-6 text-primary" />
                    </div>
                    <CardTitle>Orçamentos</CardTitle>
                    <CardDescription>
                      Defina metas por categoria e receba alertas ao ultrapassar
                    </CardDescription>
                  </CardHeader>
                </Card>
              </motion.div>

              <motion.div variants={fadeInUp}>
                <Card className="h-full hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                      <Download className="w-6 h-6 text-primary" />
                    </div>
                    <CardTitle>Export/Import</CardTitle>
                    <CardDescription>
                      Exporte seus dados em CSV/Excel ou importe planilhas existentes
                    </CardDescription>
                  </CardHeader>
                </Card>
              </motion.div>

              <motion.div variants={fadeInUp}>
                <Card className="h-full hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                      <Shield className="w-6 h-6 text-primary" />
                    </div>
                    <CardTitle>Privacidade Total</CardTitle>
                    <CardDescription>
                      Seus dados ficam no seu navegador. Nada é enviado para servidores
                    </CardDescription>
                  </CardHeader>
                </Card>
              </motion.div>

              <motion.div variants={fadeInUp}>
                <Card className="h-full hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                      <Smartphone className="w-6 h-6 text-primary" />
                    </div>
                    <CardTitle>Responsivo</CardTitle>
                    <CardDescription>
                      Funciona perfeitamente em celular, tablet e desktop
                    </CardDescription>
                  </CardHeader>
                </Card>
              </motion.div>
            </motion.div>
          </div>
        </section>

        {/* Screenshots Section */}
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div 
              className="text-center mb-16"
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
              variants={fadeInUp}
            >
              <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">
                Interface moderna e intuitiva
              </h2>
              <p className="text-xl text-muted-foreground">
                Desenvolvido com foco na experiência do usuário
              </p>
            </motion.div>

            <motion.div 
              className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center"
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
              variants={staggerContainer}
            >
              <motion.div variants={fadeInUp}>
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-secondary/20 rounded-lg blur-xl" />
                  <img 
                    src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&h=400&fit=crop&crop=center"
                    alt="Dashboard Preview"
                    className="relative rounded-lg w-full h-64 object-cover"
                  />
                </div>
              </motion.div>

              <motion.div variants={fadeInUp} className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <TrendingUp className="w-4 h-4 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-primary mb-2">Dashboard Inteligente</h3>
                    <p className="text-muted-foreground">
                      Veja seus KPIs principais, gasto médio diário e comparações mensais
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <BarChart3 className="w-4 h-4 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-primary mb-2">Relatórios Visuais</h3>
                    <p className="text-muted-foreground">
                      Gráficos de pizza, barras e linhas com animações suaves
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <Wallet className="w-4 h-4 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-primary mb-2">Controle Completo</h3>
                    <p className="text-muted-foreground">
                      Categorias personalizadas, tags, anexos e descrições detalhadas
                    </p>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-primary/5">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
              variants={staggerContainer}
            >
              <motion.h2 
                className="text-3xl md:text-4xl font-bold text-primary mb-4"
                variants={fadeInUp}
              >
                Comece hoje mesmo
              </motion.h2>
              
              <motion.p 
                className="text-xl text-muted-foreground mb-8"
                variants={fadeInUp}
              >
                Gratuito para sempre. Seus dados ficam seguros no seu navegador.
              </motion.p>
              
              <motion.div 
                className="flex flex-col sm:flex-row gap-4 justify-center"
                variants={fadeInUp}
              >
                <Button size="lg" onClick={handleGetStarted}>
                  Criar Conta Gratuita
                </Button>
                <Button variant="outline" size="lg" onClick={handleGuestMode}>
                  Testar sem Cadastro
                </Button>
              </motion.div>
            </motion.div>
          </div>
        </section>

        {/* Footer */}
        <footer className="border-t border-border py-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center text-muted-foreground">
              <p className="mb-2">
                <span className="font-semibold text-primary">Criado por Tony</span> • 
                Gratuito e de uso privado
              </p>
              <p className="text-sm">
                Seus dados nunca saem do seu navegador. 
                <button 
                  onClick={() => router.push('/about')}
                  className="ml-1 text-primary hover:underline"
                >
                  Saiba mais
                </button>
              </p>
            </div>
          </div>
        </footer>
      </div>
    </>
  );
}