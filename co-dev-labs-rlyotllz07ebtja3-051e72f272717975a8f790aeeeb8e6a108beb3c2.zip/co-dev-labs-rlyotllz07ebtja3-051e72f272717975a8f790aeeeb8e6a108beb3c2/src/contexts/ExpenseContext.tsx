import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useAuth } from './AuthContext';

export interface Transaction {
  id: string;
  date: string;
  category: string;
  subcategory?: string;
  description: string;
  paymentMethod: string;
  amount: number;
  tags: string[];
  attachment?: string;
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  subcategories: string[];
  color: string;
}

export interface Budget {
  id: string;
  categoryId: string;
  monthlyLimit: number;
  currentSpent: number;
}

interface ExpenseContextType {
  transactions: Transaction[];
  categories: Category[];
  budgets: Budget[];
  addTransaction: (transaction: Omit<Transaction, 'id' | 'createdAt'>) => void;
  updateTransaction: (id: string, transaction: Partial<Transaction>) => void;
  deleteTransaction: (id: string) => void;
  addCategory: (category: Omit<Category, 'id'>) => void;
  updateCategory: (id: string, category: Partial<Category>) => void;
  deleteCategory: (id: string) => void;
  setBudget: (categoryId: string, monthlyLimit: number) => void;
  exportData: () => void;
  importData: (data: any) => void;
}

const ExpenseContext = createContext<ExpenseContextType | undefined>(undefined);

export const useExpense = () => {
  const context = useContext(ExpenseContext);
  if (context === undefined) {
    throw new Error('useExpense must be used within an ExpenseProvider');
  }
  return context;
};

interface ExpenseProviderProps {
  children: ReactNode;
}

const defaultCategories: Category[] = [
  { id: '1', name: 'Alimentação', subcategories: ['Supermercado', 'Restaurante', 'Lanche'], color: '#ef4444' },
  { id: '2', name: 'Transporte', subcategories: ['Combustível', 'Uber', 'Ônibus'], color: '#3b82f6' },
  { id: '3', name: 'Moradia', subcategories: ['Aluguel', 'Contas', 'Manutenção'], color: '#10b981' },
  { id: '4', name: 'Lazer', subcategories: ['Cinema', 'Viagem', 'Hobbies'], color: '#f59e0b' },
  { id: '5', name: 'Saúde', subcategories: ['Médico', 'Farmácia', 'Academia'], color: '#8b5cf6' },
  { id: '6', name: 'Educação', subcategories: ['Cursos', 'Livros', 'Material'], color: '#06b6d4' },
];

export const ExpenseProvider: React.FC<ExpenseProviderProps> = ({ children }) => {
  const { user, isGuest } = useAuth();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [categories, setCategories] = useState<Category[]>(defaultCategories);
  const [budgets, setBudgets] = useState<Budget[]>([]);

  const getStorageKey = (key: string) => {
    if (isGuest) return `guest${key}`;
    if (user) return `user_${user.id}_${key}`;
    return key;
  };

  useEffect(() => {
    if (user || isGuest) {
      // Load data from localStorage
      const savedTransactions = localStorage.getItem(getStorageKey('Transactions'));
      const savedCategories = localStorage.getItem(getStorageKey('Categories'));
      const savedBudgets = localStorage.getItem(getStorageKey('Budgets'));

      if (savedTransactions) {
        setTransactions(JSON.parse(savedTransactions));
      }
      if (savedCategories) {
        setCategories(JSON.parse(savedCategories));
      } else {
        setCategories(defaultCategories);
      }
      if (savedBudgets) {
        setBudgets(JSON.parse(savedBudgets));
      }
    }
  }, [user, isGuest]);

  const saveToStorage = (key: string, data: any) => {
    localStorage.setItem(getStorageKey(key), JSON.stringify(data));
  };

  const addTransaction = (transaction: Omit<Transaction, 'id' | 'createdAt'>) => {
    const newTransaction: Transaction = {
      ...transaction,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
    };
    
    const updatedTransactions = [...transactions, newTransaction];
    setTransactions(updatedTransactions);
    saveToStorage('Transactions', updatedTransactions);
    
    // Update budget spent amount
    const budget = budgets.find(b => {
      const category = categories.find(c => c.id === b.categoryId);
      return category?.name === transaction.category;
    });
    
    if (budget) {
      const updatedBudgets = budgets.map(b => 
        b.id === budget.id 
          ? { ...b, currentSpent: b.currentSpent + transaction.amount }
          : b
      );
      setBudgets(updatedBudgets);
      saveToStorage('Budgets', updatedBudgets);
    }
  };

  const updateTransaction = (id: string, updatedTransaction: Partial<Transaction>) => {
    const updatedTransactions = transactions.map(t => 
      t.id === id ? { ...t, ...updatedTransaction } : t
    );
    setTransactions(updatedTransactions);
    saveToStorage('Transactions', updatedTransactions);
  };

  const deleteTransaction = (id: string) => {
    const transaction = transactions.find(t => t.id === id);
    const updatedTransactions = transactions.filter(t => t.id !== id);
    setTransactions(updatedTransactions);
    saveToStorage('Transactions', updatedTransactions);
    
    // Update budget spent amount
    if (transaction) {
      const budget = budgets.find(b => {
        const category = categories.find(c => c.id === b.categoryId);
        return category?.name === transaction.category;
      });
      
      if (budget) {
        const updatedBudgets = budgets.map(b => 
          b.id === budget.id 
            ? { ...b, currentSpent: Math.max(0, b.currentSpent - transaction.amount) }
            : b
        );
        setBudgets(updatedBudgets);
        saveToStorage('Budgets', updatedBudgets);
      }
    }
  };

  const addCategory = (category: Omit<Category, 'id'>) => {
    const newCategory: Category = {
      ...category,
      id: Date.now().toString(),
    };
    
    const updatedCategories = [...categories, newCategory];
    setCategories(updatedCategories);
    saveToStorage('Categories', updatedCategories);
  };

  const updateCategory = (id: string, updatedCategory: Partial<Category>) => {
    const updatedCategories = categories.map(c => 
      c.id === id ? { ...c, ...updatedCategory } : c
    );
    setCategories(updatedCategories);
    saveToStorage('Categories', updatedCategories);
  };

  const deleteCategory = (id: string) => {
    const updatedCategories = categories.filter(c => c.id !== id);
    setCategories(updatedCategories);
    saveToStorage('Categories', updatedCategories);
  };

  const setBudget = (categoryId: string, monthlyLimit: number) => {
    const existingBudget = budgets.find(b => b.categoryId === categoryId);
    
    if (existingBudget) {
      const updatedBudgets = budgets.map(b => 
        b.categoryId === categoryId 
          ? { ...b, monthlyLimit }
          : b
      );
      setBudgets(updatedBudgets);
      saveToStorage('Budgets', updatedBudgets);
    } else {
      const newBudget: Budget = {
        id: Date.now().toString(),
        categoryId,
        monthlyLimit,
        currentSpent: 0,
      };
      
      const updatedBudgets = [...budgets, newBudget];
      setBudgets(updatedBudgets);
      saveToStorage('Budgets', updatedBudgets);
    }
  };

  const exportData = () => {
    const data = {
      transactions,
      categories,
      budgets,
      exportDate: new Date().toISOString(),
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `gastos-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const importData = (data: any) => {
    if (data.transactions) {
      setTransactions(data.transactions);
      saveToStorage('Transactions', data.transactions);
    }
    if (data.categories) {
      setCategories(data.categories);
      saveToStorage('Categories', data.categories);
    }
    if (data.budgets) {
      setBudgets(data.budgets);
      saveToStorage('Budgets', data.budgets);
    }
  };

  const value = {
    transactions,
    categories,
    budgets,
    addTransaction,
    updateTransaction,
    deleteTransaction,
    addCategory,
    updateCategory,
    deleteCategory,
    setBudget,
    exportData,
    importData,
  };

  return (
    <ExpenseContext.Provider value={value}>
      {children}
    </ExpenseContext.Provider>
  );
};